<?php

// Silence is golden.
?>