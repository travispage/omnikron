/*
* Plugin Name: Magic Liquidizer - noConflict
* Plugin URI: http://www.innovedesigns.com/
* Author: Elvin Deza
* Description: Avoiding jQuery conflicts
* Version: 
* Tags: form, responsive, fluid
* Author URI: http://innovedesigns.com/author/esstat17
*/

var ml=jQuery.noConflict();