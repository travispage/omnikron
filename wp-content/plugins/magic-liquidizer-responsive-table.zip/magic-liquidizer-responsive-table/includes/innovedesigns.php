<?php
defined( 'ABSPATH' ) OR exit;

/*
/--------------------------------------------------------------------\
|                                                                    |
| License: GLP Version 3                                             |
|                                                                    |
| Magic Liquidizer Responsive Table - Make HTML Table Responsive.    |
| Copyright (C) 2014, Elvin Deza,                                    |
| http://innovedesigns.com/                                          |
| All rights reserved.                                               |
|                                                                    |
| By using the software, you agree to be bound by the terms of		 | 		
| this license.														 |
| 																	 |
|                                                                    |
\--------------------------------------------------------------------/
*/

// $txt=get_option('liquidizer_lite_wp_lisensya_key'); $re1='(id)'; $re2='.*?'; $re3='\\d+'; $re4='.*?'; $re5='(\\d+)'; if($c=preg_match_all ("/".$re1.$re2.$re3.$re4.$re5."/is", $txt, $matches)){ $word1=$matches[1][0]; $int1=$matches[2][0]; } 
