=== Plugin Name ===
Contributors: wordpressdotorg
Tags: importer, rss
Requires at least: 3.0
Tested up to: 4.7
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Import posts from an RSS feed.

== Description ==

Import posts from an RSS feed.

== Installation ==

1. Upload the `rss-importer` folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Go to the Tools -> Import screen, Click on RSS

== Frequently Asked Questions ==

== Screenshots ==

== Changelog ==

= 0.2 =
* Update compat
* Add text domain headers

= 0.1 =
* Initial release
