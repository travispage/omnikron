<?php /* general options for almost every form box - background colors, patterns, images etc */ ?>
<?php $has_custom_colors = 1;
include $menu_path . '_custom_colors.php' ?>
<?php include dirname( __FILE__ ) . '/_border_controls.php' ?>
<?php include $menu_path . '_margin.php' ?>
<?php include dirname( __FILE__ ) . '/_background_controls.php' ?>