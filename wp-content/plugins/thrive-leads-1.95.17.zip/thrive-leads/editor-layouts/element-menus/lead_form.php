<?php
/**
 * General menu for lead forms
 */
?>
<div id="lead_form_menu">
	<span class="tve_options_headline"><span class="tve_icm tve-ic-move"></span><?php echo __( 'Element options', 'thrive-leads' ) ?></span>
	<ul class="tve_menu">
		<?php include dirname( __FILE__ ) . '/_form_box.php' ?>
	</ul>
</div>