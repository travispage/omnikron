<div id="lightbox_menu">
	<?php include $menu_path . '/lightbox.php' ?>
</div>