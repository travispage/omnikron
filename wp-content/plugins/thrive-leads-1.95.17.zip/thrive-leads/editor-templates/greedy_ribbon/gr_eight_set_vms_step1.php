<div class="thrv-greedy-ribbon tve_no_drag tve_no_icons tve_element_hover thrv_wrapper tve_gr_eight_set tve_white"
     style="background-image: url('<?php echo TVE_LEADS_URL . 'editor-templates/_form_css/images/gr_eight_set_bg.jpg' ?>');background-size: cover; background-position: center center;">
	<div class="tve-greedy-ribbon-content tve_editor_main_content">
		<div class="thrv_wrapper thrv_content_container_shortcode">
			<div class="tve_clear"></div>
			<div class="tve_center tve_content_inner" style="width: 910px;min-width:50px; min-height: 2em;">
				<h2 class="tve_p_center rft" style="color: #fff; font-size: 80px;margin-top: 40px;margin-bottom: 0;">
					Travel more <br>
					by saving on transport
				</h2>
			</div>
			<div class="tve_clear"></div>
		</div>
		<div class="thrv_wrapper thrv_content_container_shortcode">
			<div class="tve_clear"></div>
			<div class="tve_center tve_content_inner"
			     style="width: 1050px;min-width:50px; min-height: 2em;margin-top: 40px;">
				<div class="thrv_wrapper thrv_contentbox_shortcode" data-tve-style="6">
					<div class="tve_cb tve_cb6 tve_white">
						<div class="tve_cb_cnt">
							<div class="thrv_wrapper thrv_content_container_shortcode">
								<div class="tve_clear"></div>
								<div class="tve_center tve_content_inner" style="width: 750px;min-width:50px; min-height: 2em;margin-top: 60px;margin-bottom: 80px;">
									<p class="tve_p_center"
									   style="color: #333; font-size: 22px;margin-top: 0;margin-bottom: 0;">
										Nullam bibendum sit amet est et porta. Nam ac felis accumsan leo euismod tincidunt vel
										vel tortor. Duis nec consequat nibh. Morbi pellentesque sollicitudin magna sit amet
										pretium.
									</p>
								</div>
								<div class="tve_clear"></div>
							</div>
							<div class="thrv_wrapper thrv_content_container_shortcode">
								<div class="tve_clear"></div>
								<div class="tve_center tve_content_inner" style="width: 410px;min-width:50px; min-height: 2em;margin-top: 0;margin-bottom: -80px;">
									<div class="thrv_wrapper thrv_button_shortcode tve_fullwidthBtn" data-tve-style="1">
										<div class="tve_btn tve_btn3 tve_nb tve_blue tve_normalBtn">
											<a class="tve_btnLink tve_evt_manager_listen tve_et_click" href=""
											   data-tcb-events="|open_state_2|">
                                                <span class="tve_left tve_btn_im">
                                                    <i></i>
                                                    <span class="tve_btn_divider"></span>
                                                </span>
												<span class="tve_btn_txt">Read the Articles</span>
											</a>
										</div>
									</div>
								</div>
								<div class="tve_clear"></div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="tve_clear"></div>
		</div>
		<div class="thrv_wrapper thrv_icon aligncenter gr-close-button tve_no_drag">
            <span data-tve-icon="gr-eight-set-close"
                  class="tve_sc_icon gr-eight-set-close tve_white tve_evt_manager_listen tve_et_click"
                  style="font-size: 90px;" data-tcb-events="|close_form|"></span>
		</div>
	</div>
</div>


