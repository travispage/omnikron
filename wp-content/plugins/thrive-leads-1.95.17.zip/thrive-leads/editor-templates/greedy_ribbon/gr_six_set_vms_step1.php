<div class="thrv-greedy-ribbon tve_no_drag tve_no_icons tve_element_hover thrv_wrapper tve_gr_six_set tve_white">
	<div class="tve-greedy-ribbon-content tve_editor_main_content">
		<div class="thrv_wrapper thrv_contentbox_shortcode" data-tve-style="5">
			<div class="tve_cb tve_cb5 tve_purple">
				<div class="tve_cb_cnt">
					<div style="margin-top: 80px;margin-bottom: -105px;width: 210px;" class="thrv_wrapper tve_image_caption aligncenter img_style_circle gr_six_set_image">
                         <span class="tve_image_frame">
                            <img class="tve_image"
                                 src="<?php echo TVE_LEADS_URL . 'editor-templates/_form_css/images/gr_set_six_image.jpg' ?>"
                                 style="width: 210px"/>
                        </span>
					</div>
				</div>
			</div>
		</div>
		<div class="thrv_wrapper thrv_content_container_shortcode">
			<div class="tve_clear"></div>
			<div class="tve_center tve_content_inner" style="width: 850px;min-width:50px; min-height: 2em;margin-top: 120px;">
				<h2 class="tve_p_center rft" style="color: #ff5980; font-size: 65px;margin-top: 0;margin-bottom: 50px;">
					Get more female followers
					with this new mat-style form
				</h2>
				<p class="tve_p_center" style="color: #666666; font-size: 22px;margin-top: 0;margin-bottom: 80px;">
					Tell them about your products major advantages and use the photo above to illustrate your product, or use as author photo.
				</p>
			</div>
			<div class="tve_clear"></div>
		</div>
		<div class="thrv_wrapper thrv_content_container_shortcode">
			<div class="tve_clear"></div>
			<div class="tve_center tve_content_inner" style="width: 460px;min-width:50px; min-height: 2em;">
				<div class="thrv_wrapper thrv_button_shortcode tve_fullwidthBtn" data-tve-style="1">
					<div class="tve_btn tve_btn3 tve_nb tve_purple tve_normalBtn">
						<a class="tve_btnLink tve_evt_manager_listen tve_et_click" href=""
						   data-tcb-events="|open_state_2|">
                                    <span class="tve_left tve_btn_im">
                                        <i></i>
                                        <span class="tve_btn_divider"></span>
                                    </span>
							<span class="tve_btn_txt">Show me the Product</span>
						</a>
					</div>
				</div>
			</div>
			<div class="tve_clear"></div>
		</div>

		<div class="thrv_wrapper thrv_icon aligncenter gr-close-button tve_no_drag">
            <span data-tve-icon="gr-six-set-close"
                  class="tve_sc_icon gr-six-set-close tve_white tve_evt_manager_listen tve_et_click"
                  style="font-size: 60px;" data-tcb-events="|close_form|"></span>
		</div>
	</div>
</div>


