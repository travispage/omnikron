<span class="tve_options_headline"><span class="tve_icm tve-ic-move"></span><?php echo __( 'Columns options', 'thrive-cb' ) ?></span>
<ul class="tve_menu">
	<?php include dirname( __FILE__ ) . '/_margin.php' ?>
	<li class="tve_ed_btn tve_btn_text tve_center tve_click" data-ctrl="drag.convert_old_columns"><?php echo __( 'Convert columns to the new format', 'thrive-cb' ) ?></li>
</ul>