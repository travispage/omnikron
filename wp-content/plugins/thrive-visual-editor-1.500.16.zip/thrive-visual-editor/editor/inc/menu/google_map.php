<span class="tve_options_headline"><span class="tve_icm tve-ic-move"></span><?php echo __( "Google Maps options", "thrive-cb" ) ?></span>
<ul class="tve_menu">
	<li id="lb_google_map" class="tve_ed_btn tve_btn_text tve_click" data-ctrl="controls.lb_open" data-multiple-hide><?php echo __( "Edit Google Map Code", "thrive-cb" ) ?>
	</li>
	<?php include dirname( __FILE__ ) . '/_margin.php' ?>
</ul>