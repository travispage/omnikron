<h4><?php echo __( "Insert Custom CSS into the page. Be sure only to add CSS code to the text area below !", "thrive-cb" ) ?></h4>
<hr class="tve_lightbox_line"/>
<input type="hidden" name="tve_lb_type" value="tve_custom_css">
<textarea name="tve_custom_css" class="tve_lightbox_textarea tve_textarea_large"><?php echo __( "/** Insert your custom CSS rules here. **/", "thrive-cb" ) ?></textarea>
