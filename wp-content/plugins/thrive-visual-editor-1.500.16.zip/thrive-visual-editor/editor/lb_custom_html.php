<h4><?php echo __( "Insert Custom HTML into the Page", "thrive-cb" ) ?></h4>
<hr class="tve_lightbox_line"/>
<input type="hidden" name="tve_lb_type" value="custom_html">
<textarea name="tve_custom_html" id="tve_custom_html" class="tve_lightbox_textarea tve_textarea_large">
<?php echo __( "Insert your HTML content here.", "thrive-cb" ) ?>
</textarea>
