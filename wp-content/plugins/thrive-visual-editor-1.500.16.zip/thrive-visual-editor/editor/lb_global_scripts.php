<input type="hidden" name="tve_lb_type" value="global_scripts">

<p><?php echo __( "Header scripts (Before the <strong>&lt;/head&gt;</strong> end tag)", 'thrive-cb' ) ?></p>
<textarea name="head" class="tve_lightbox_textarea tve_textarea_normal" id="tve_global_scripts_head"></textarea>

<p><?php echo __( "Body (header) scripts (Immediately after the <strong>&lt;body&gt;</strong> tag)", "thrive-cb" ) ?></p>
<textarea name="body" class="tve_lightbox_textarea tve_textarea_normal" id="tve_global_scripts_body"></textarea>

<p><?php echo __( "Body (footer) scripts (Before the <strong>&lt;/body&gt;</strong> end tag)", "thrive-cb" ) ?></p>
<textarea name="footer" class="tve_lightbox_textarea tve_textarea_normal" id="tve_global_scripts_footer"></textarea>
