<h4>Widget</h4>
<hr class="tve_lightbox_line"/>
<p class="tve_widgets_list_container">
	<label>Select widget</label>
	<select class="tve_widgets_list">
		<option value="">Select widget</option>
	</select>
</p>
<input type="hidden" name="tve_lb_type" value="widgets">
<div id="options_container"></div>
