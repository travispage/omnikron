<p>
	<?php echo __("Sorry, no results could be found for", "thrive-cb") ?><br/>
	<span class="tve-result-text"></span>
</p>

<div class="tve-posts-not-found-btns">
	<a href="javascript:void(0)" class="tve_click tve_no_click tve-clear-search" data-ctrl="controls.change_search"><?php echo __( "Clear ", "thrive-cb" ) ?></a>
	<span id="lb_text_link_settings" class="tve_no_click tve_click tve_lb_small tve_mousedown" data-ctrl-mousedown="controls.save_selection" data-ctrl-click="controls.lb_open"><?php echo __("Settings", "thrive-cb") ?></span>
</div>