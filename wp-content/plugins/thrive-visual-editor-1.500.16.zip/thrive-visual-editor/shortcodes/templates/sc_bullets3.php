<div class="thrv_wrapper thrv_bullets_shortcode">
	<ul class="tve_ul tve_ul3 tve_red">
		<li>Bullet Point 1</li>
		<li>Bullet Point 2</li>
	</ul>
</div>