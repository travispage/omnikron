<div class="thrv_wrapper thrv_bullets_shortcode">
	<ul class="tve_ul tve_ul6 tve_red">
		<li>li li li</li>
		<li>li li li</li>
	</ul>
</div>