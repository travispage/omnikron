<div class="thrv_wrapper thrv_calltoaction_shortcode" data-tve-style="3">
	<div class="tve_ca tve_ca3 tve_red">
		<div class="tve_ca_o">
			<h2 class="tve_ca_heading">LOREM IPSUM DOLOR SIT AMET ELIT</h2>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et.</p>
		</div>
		<div class="tve_ca_t">
			<div class="tve_btn tve_btn2 tve_red tve_normalBtn">
				<a class="tve_btnLink" href="">
					<span>Buy it Now!</span>
					<span class="tve_ca_sp">lorem ipsum dolor</span>
				</a>
			</div>
		</div>
		<div class="tve_corner"></div>
		<div class="tve_clear"></div>
	</div>
</div>