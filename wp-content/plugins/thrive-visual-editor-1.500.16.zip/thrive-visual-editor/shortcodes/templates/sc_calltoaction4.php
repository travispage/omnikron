<div class="thrv_wrapper thrv_calltoaction_shortcode" data-tve-style="4">
	<div class="tve_ca tve_ca4 tve_red">
		<h2 class="tve_ca_heading">LOREM IPSUM DOLOR SIT AMET ELIT</h2>
		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore
			et
			dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut
			aliquip
			ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum
			dolore eu
			fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia
			deserunt mollit anim id est laborum.</p>
		<div class="tve_btn_cnt">
			<div class="tve_btn tve_btn3 tve_red tve_normalBtn">
				<a class="tve_btnLink" href="">
					<span>Buy it Now!</span>
					<span class="tve_ca_sp">lorem ipsum dolor</span>
				</a>
			</div>
			<b></b>
		</div>
	</div>
</div>