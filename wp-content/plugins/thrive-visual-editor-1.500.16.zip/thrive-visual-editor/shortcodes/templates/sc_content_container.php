<div class="thrv_wrapper thrv_content_container_shortcode">
	<div class="tve_clear"></div>
	<div class="tve_center tve_content_inner" style="min-width: 50px; min-height: 2em;">
		<p><?php echo __( 'Your content here...', 'thrive-cb' ) ?></p>
	</div>
	<div class="tve_clear"></div>
</div>