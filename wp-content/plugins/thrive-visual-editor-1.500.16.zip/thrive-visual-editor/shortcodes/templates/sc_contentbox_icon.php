<div class="thrv_wrapper thrv_contentbox_shortcode" data-tve-style="symbol">
	<div class="tve_cb tve_cb_symbol tve_red">
		<?php $cb_icon = true;
		include TVE_TEMPLATES_PATH . '/sc_icon.php' ?>
		<div class="tve_cb_cnt">
			<p><span class="bold_text">MAIN LABEL</span></p>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestiae, officia? </p>
		</div>
	</div>
</div>