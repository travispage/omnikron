<div class="thrv_wrapper thrv_contents_table tve_ct tve_blue tve_clearfix" data-tve-style="1" data-columns="2">
	<div class="tve_contents_table tve_clearfix">
		<span class="tve_ct_title"><?php echo __( 'Quick Navigation', 'thrive-cb' ) ?></span>
		<div class="tve_ct_content tve_clearfix"></div>
	</div>
</div>