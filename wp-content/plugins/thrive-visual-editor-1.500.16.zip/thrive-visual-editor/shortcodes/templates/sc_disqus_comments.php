<div class="thrv_wrapper thrv_disqus_comments">
	<div id="disqus_thread" data-disqus_identifier="<?php echo get_the_ID(); ?>" data-disqus_shortname="<?php echo $tve_disqus_shortname; ?>"
	     data-disqus_url=""></div>
</div>