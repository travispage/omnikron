<div class="thrv_wrapper">
	<hr class="tve_sep tve_sep3"/>
</div>