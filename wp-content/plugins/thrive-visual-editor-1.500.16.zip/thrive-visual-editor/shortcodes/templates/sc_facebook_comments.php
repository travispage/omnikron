<div class="thrv_wrapper thrv_facebook_comments">
	<div class="tve-fb-comments" data-colorscheme="light" data-numposts="20" data-order-by="social" data-width="100%" data-href=""
	     data-fb-moderator-ids="<?php echo $tve_facebook_admins; ?>"></div>
</div>