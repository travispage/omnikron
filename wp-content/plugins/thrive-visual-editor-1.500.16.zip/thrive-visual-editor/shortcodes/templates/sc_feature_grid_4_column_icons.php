<div class="thrv_wrapper thrv_feature_grid tve_gr tve_gr3" data-tve-style="1">
	<div class="tve_colm tve_foc">
		<div class="tve_left tve_gri">
			<?php include TVE_TEMPLATES_PATH . '/sc_icon.php' ?>
		</div>
		<div class="tve_left tve_grt">
			<h3>Heading 1</h3>

			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Libero, vero?</p>
		</div>
		<div class="tve_clear"></div>
	</div>
	<div class="tve_colm tve_foc">
		<div class="tve_left tve_gri">
			<?php include TVE_TEMPLATES_PATH . '/sc_icon.php' ?>
		</div>
		<div class="tve_left tve_grt">
			<h3>Heading 2</h3>

			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Libero, vero?</p>
		</div>
		<div class="tve_clear"></div>
	</div>
	<div class="tve_colm tve_foc">
		<div class="tve_left tve_gri">
			<?php include TVE_TEMPLATES_PATH . '/sc_icon.php' ?>
		</div>
		<div class="tve_left tve_grt">
			<h3>Heading 3</h3>

			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Libero, vero?</p>
		</div>
		<div class="tve_clear"></div>
	</div>
	<div class="tve_colm tve_foc tve_lst">
		<div class="tve_left tve_gri">
			<?php include TVE_TEMPLATES_PATH . '/sc_icon.php' ?>
		</div>
		<div class="tve_left tve_grt">
			<h3>Heading 4</h3>

			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Libero, vero?</p>
		</div>
		<div class="tve_clear"></div>
	</div>
	<div class="tve_clear"></div>
</div>