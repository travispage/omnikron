<div class="thrv_wrapper thrv_fill_counter tve_red tve_normalfc thrv_data_element" data-tve-style="1">
	<div class="tve_fill_counter_n" style="stroke-dasharray: 476.25 635;" data-fill="75">
		<svg viewBox="0 0 202 202" class="tve_fill_counter_circle" shape-rendering="optimizeSpeed">
			<circle r="101" cx="101" cy="101"></circle>
		</svg>
		<div class="tve_fill_text_in">
			<div class="tve_fill_text_value">
				<span class="tve_fill_text_before"></span>
				<span class="tve_fill_text">75</span>
				<span class="tve_fill_text_after">%</span>
			</div>
			<span class="tve_data_element_label">
                        Fill Counter
                    </span>
		</div>
	</div>
</div>