<div class="image_placeholder thrv_wrapper">
	<a class="tve_click tve_green_button clearfix" id="lb_google_map" data-ctrl="controls.lb_open">
		<i class="tve_icm tve-ic-upload"></i>
		<span><?php echo __( 'Embed Google Map', 'thrive-cb' ) ?></span>
	</a>
</div>