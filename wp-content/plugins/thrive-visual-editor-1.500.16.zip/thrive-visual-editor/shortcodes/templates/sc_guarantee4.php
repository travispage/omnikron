<div class="thrv_wrapper thrv_guarantee_shortcode" data-tve-style="4">
	<div class="tve_fg tve_fg4 tve_red">
		<div class="tve_rbn">
			<span class="tve_badge"></span>

			<div class="tve_line tve_left">
				<h3>100% MONEY BACK GUARANTEE</h3>
			</div>
			<span class="tve_left"></span>

			<div class="tve_clear"></div>
		</div>
		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore
			et
			dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut
			aliquip
			ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum
			dolore eu
			fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia
			deserunt mollit anim id est laborum.</p>
	</div>
</div>