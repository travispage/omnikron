<div class="thrv_wrapper thrv_progress_bar tve_red thrv_data_element" data-tve-style="1">
	<div class="tve_progress_bar">
		<div class="tve_progress_bar_fill_wrapper" style="width: 20%;" data-fill="20">
			<div class="tve_progress_bar_fill"></div>
			<div class="tve_data_element_label">
				Progress Bar
			</div>
		</div>
	</div>
</div>