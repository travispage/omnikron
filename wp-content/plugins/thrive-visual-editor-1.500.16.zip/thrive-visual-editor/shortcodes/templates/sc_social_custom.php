<div class="thrv_wrapper thrv_social thrv_social_custom">
	<div class="tve_social_items tve_social_custom tve_style_1 tve_social_medium tve_social_itb">
		<div class="tve_s_item tve_s_fb_share" data-s="fb_share" data-href="{tcb_post_url}">
			<a href="javascript:void(0)" class="tve_s_link"><span class="tve_s_icon"></span><span
					class="tve_s_text">Share</span><span
					class="tve_s_count">0</span></a>
		</div>
		<div class="tve_s_item tve_s_g_share" data-s="g_share" data-href="{tcb_post_url}">
			<a href="javascript:void(0)" class="tve_s_link"><span class="tve_s_icon"></span><span
					class="tve_s_text">Share +1</span><span
					class="tve_s_count">0</span></a>
		</div>
		<div class="tve_s_item tve_s_t_share" data-s="t_share" data-href="{tcb_post_url}">
			<a href="javascript:void(0)" class="tve_s_link"><span class="tve_s_icon"></span><span
					class="tve_s_text">Tweet</span><span
					class="tve_s_count">0</span></a>
		</div>
	</div>
	<div class="tve_social_overlay"></div>
</div>