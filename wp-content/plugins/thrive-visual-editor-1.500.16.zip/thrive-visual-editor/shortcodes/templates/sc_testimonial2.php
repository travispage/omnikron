<div class="thrv_wrapper thrv_testimonial_shortcode" data-tve-style="2">
	<div class="tve_ts tve_ts2 tve_red">
		<div class="tve_ts_o">
			<div class="tve_ts_imc">
				<img class="tve_image" src="<?php echo tve_editor_css(); ?>/images/photo1.jpg" alt=""/>
			</div>
			<span style="display:block"><b>John Doe</b>UI/UX Designer</span>
		</div>
		<div class="tve_ts_t">
			<div class="tve_ts_cn">
				<span class="tve_ts_ql"></span>

				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut
					labore et
					dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi
					ut aliquip
					ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
					cillum dolore eu
					fugiat nulla pariatur.</p>
				<span class="tve_ts_qr"></span>
			</div>
		</div>
		<div class="tve_clear"></div>
	</div>
</div>