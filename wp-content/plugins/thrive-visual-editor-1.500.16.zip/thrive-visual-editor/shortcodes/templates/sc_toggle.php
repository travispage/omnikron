<div class="thrv_wrapper thrv_toggle_shortcode tve_red">
	<div class="tve_faq">
		<div class="tve_faqI">
			<div class="tve_faqB"><span class="tve_not_editable tve_toggle"></span>
				<h4><?php echo __( "Content Toggle Headline", "thrive-cb" ) ?></h4>
			</div>
			<div class="tve_faqC" style="display: none;">
				<p><?php echo __( "Add your content here...", 'thrive-cb' ) ?></p></div>
		</div>
	</div>
</div>