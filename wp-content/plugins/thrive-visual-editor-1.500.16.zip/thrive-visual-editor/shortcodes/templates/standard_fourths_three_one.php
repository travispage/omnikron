<?php /* <div class="thrv_wrapper thrv_columns tve_clearfix">
	<div class="tve_colm tve_tfo tve_df "><p><?php echo sprintf( __( "Column %s", "thrive-cb" ), "1" ) ?></p></div>
	<div class="tve_colm  tve_foc tve_ofo tve_df tve_lst"><p><?php echo sprintf( __( "Column %s", "thrive-cb" ), "2" ) ?></p></div>
</div> */ ?>

<div class="thrv_wrapper tcb-flex-row tcb--cols--2">
	<div class="tcb-flex-col c-75"><p><?php echo sprintf( __( 'Column %s', 'thrive-cb' ), 1 ) ?></p></div>
	<div class="tcb-flex-col c-25"><p><?php echo sprintf( __( 'Column %s', 'thrive-cb' ), 2 ) ?></p></div>
</div>


