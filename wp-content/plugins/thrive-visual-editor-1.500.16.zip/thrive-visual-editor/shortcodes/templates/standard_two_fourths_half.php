<?php /*<div class="thrv_wrapper thrv_columns">
	<div class="tve_colm tve_foc tve_df tve_fft"><p><?php echo sprintf( __( "Column %s", "thrive-cb" ), "1" ) ?></p>
	</div>
	<div class="tve_colm tve_foc tve_df tve_fft"><p><?php echo sprintf( __( "Column %s", "thrive-cb" ), "2" ) ?></p>
	</div>
	<div class="tve_colm tve_twc tve_lst"><p><?php echo sprintf( __( "Column %s", "thrive-cb" ), "3" ) ?></p></div>
</div>*/ ?>
<div class="thrv_wrapper tcb-flex-row tcb--cols--3">
	<div class="tcb-flex-col c-25"><p><?php echo sprintf( __( 'Column %s', 'thrive-cb' ), 1 ) ?></p></div>
	<div class="tcb-flex-col c-25"><p><?php echo sprintf( __( 'Column %s', 'thrive-cb' ), 2 ) ?></p></div>
	<div class="tcb-flex-col c-50"><p><?php echo sprintf( __( 'Column %s', 'thrive-cb' ), 3 ) ?></p></div>
</div>
