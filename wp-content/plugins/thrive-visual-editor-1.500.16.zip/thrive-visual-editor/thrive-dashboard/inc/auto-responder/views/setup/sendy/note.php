<div class="tve-sp"></div>
<p><?php echo __( "Note: we would prefer displaying the list names instead of IDs here, but unfortunately that isn't possible with Sendy.", TVE_DASH_TRANSLATE_DOMAIN ) ?></p>
